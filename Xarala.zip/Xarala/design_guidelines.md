# Design Guidelines - Système d'Information et de Gestion des Notes (SIR)

## Design Approach: Material Design System
**Justification**: Educational management system requiring clarity, data density, and multi-role access. Material Design provides excellent patterns for dashboards, tables, forms, and role-based interfaces while maintaining professional aesthetics.

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: 220 85% 45% (Professional blue for trust/education)
- Primary Hover: 220 85% 35%
- Secondary: 160 70% 45% (Green for success/grades)
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Text Primary: 220 15% 15%
- Text Secondary: 220 10% 45%
- Border: 220 10% 90%

**Dark Mode:**
- Primary: 220 75% 60%
- Primary Hover: 220 75% 70%
- Secondary: 160 60% 55%
- Background: 220 15% 10%
- Surface: 220 15% 15%
- Text Primary: 220 10% 95%
- Text Secondary: 220 10% 70%
- Border: 220 10% 25%

**Semantic Colors:**
- Success: 142 70% 45% (Approved grades/requests)
- Warning: 38 92% 50% (Pending actions)
- Error: 0 70% 50% (Failed grades/alerts)
- Info: 200 90% 50% (Notifications)

### B. Typography
- **Primary Font**: Inter (via Google Fonts CDN)
- **Headings**: 
  - H1: 2.5rem/3rem, font-bold (Dashboard titles)
  - H2: 2rem/2.5rem, font-semibold (Section headers)
  - H3: 1.5rem/2rem, font-semibold (Card titles)
  - H4: 1.25rem/1.75rem, font-medium (Sub-sections)
- **Body**: 1rem/1.5rem, font-normal
- **Small**: 0.875rem/1.25rem (Table data, metadata)
- **Caption**: 0.75rem/1rem (Timestamps, helper text)

### C. Layout System
**Spacing Scale**: Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-4, p-6, p-8
- Section spacing: space-y-6, space-y-8
- Card gaps: gap-4, gap-6
- Container margins: mx-4, mx-6, mx-8

**Grid System**: 
- Desktop: 12-column grid (max-w-7xl)
- Tablet: 8-column grid
- Mobile: 4-column grid

### D. Component Library

**Navigation:**
- Top navbar with role indicator badge
- Sidebar navigation (collapsible on mobile)
- Breadcrumbs for deep navigation
- Tab navigation for multi-view pages

**Dashboards:**
- Card-based layouts with rounded-lg borders
- Statistics cards (grid-cols-1 md:grid-cols-2 lg:grid-cols-4)
- Data tables with sticky headers
- Chart containers with subtle shadows

**Forms:**
- Floating label inputs
- Grouped form sections with dividers
- Multi-step forms for complex data entry
- Inline validation with real-time feedback
- File upload zones with preview

**Data Displays:**
- Sortable tables with hover states
- Grade cards with color-coded performance
- Timeline views for schedule/history
- Progress indicators for completion
- Badge system for status (Approuvé, En attente, Rejeté)

**Role-Specific Elements:**
- **Élèves**: Grade cards, schedule calendar, request forms
- **Professeurs**: Grade input tables, class management, bulletin generation
- **Parents**: Child selector dropdown, grade overview, messaging
- **Secrétariat**: Admin tables, bulk actions, approval workflows

**Overlays:**
- Modal dialogs for confirmations (max-w-lg centered)
- Slide-over panels for quick actions (w-96 from right)
- Toast notifications (top-right, auto-dismiss)
- Dropdown menus with icon indicators

### E. Animations
Use sparingly for feedback only:
- Button press: scale-95 active state
- Modal entrance: fade + slide-up (duration-200)
- Tab transitions: fade-in (duration-150)
- NO page transitions or decorative animations

## Page-Specific Guidelines

**Login/Auth**: Centered card (max-w-md), school logo, language toggle (FR/EN)

**Dashboard**: 4-column stats grid, recent activity feed, quick actions, role-appropriate widgets

**Grades Management**: 
- Table layout with sticky column headers
- Color-coded grade ranges
- Bulk edit capabilities
- Export to PDF functionality

**Schedule**: Full calendar view (day/week/month), drag-drop disabled for students, color-coded by subject

**Réclamations**: Kanban board or list view with status filters, priority badges, assignee avatars

**Bulletins**: PDF preview panel, print-ready layout, signature fields, official stamp area

## Accessibility & Quality
- WCAG AA contrast ratios minimum
- Keyboard navigation for all interactions
- Screen reader labels on data tables
- Focus indicators (ring-2 ring-primary)
- Dark mode toggle in user preferences
- Consistent form field heights (h-10 standard)
- Clear error states with aria-live regions