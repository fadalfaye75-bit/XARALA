import { useState } from "react";
import { AbsenceCard } from "@/components/AbsenceCard";
import { Button } from "@/components/ui/button";
import { Upload } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AbsencesPage() {
  const [open, setOpen] = useState(false);

  const absences = [
    {
      id: "1",
      date: "20 Jan 2025",
      subject: "Mathématiques",
      period: "08:00 - 09:30",
      status: "justified" as const,
      reason: "Rendez-vous médical",
      teacher: "M. Benali",
    },
    {
      id: "2",
      date: "18 Jan 2025",
      subject: "Physique",
      period: "10:00 - 11:30",
      status: "unjustified" as const,
      teacher: "Mme. Amrani",
    },
    {
      id: "3",
      date: "19 Jan 2025",
      subject: "Français",
      period: "14:00 - 15:30",
      status: "pending" as const,
      reason: "Certificat médical en cours de validation",
      teacher: "Mme. Fassi",
    },
    {
      id: "4",
      date: "15 Jan 2025",
      subject: "Sport",
      period: "16:00 - 17:30",
      status: "justified" as const,
      reason: "Blessure au genou",
      teacher: "M. Tazi",
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Justificatif soumis");
    setOpen(false);
  };

  const totalAbsences = absences.length;
  const justified = absences.filter(a => a.status === "justified").length;
  const unjustified = absences.filter(a => a.status === "unjustified").length;
  const pending = absences.filter(a => a.status === "pending").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Mes Absences</h1>
          <p className="text-muted-foreground">
            Consultez et justifiez vos absences
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-justify-absence">
              <Upload className="h-4 w-4 mr-2" />
              Justifier une absence
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Justifier une absence</DialogTitle>
              <DialogDescription>
                Fournissez un justificatif pour votre absence
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="absence">Absence à justifier</Label>
                <Select>
                  <SelectTrigger id="absence" data-testid="select-absence">
                    <SelectValue placeholder="Sélectionnez une absence" />
                  </SelectTrigger>
                  <SelectContent>
                    {absences
                      .filter(a => a.status === "unjustified")
                      .map(a => (
                        <SelectItem key={a.id} value={a.id}>
                          {a.subject} - {a.date}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reason">Motif</Label>
                <Textarea
                  id="reason"
                  placeholder="Expliquez la raison de votre absence..."
                  rows={3}
                  data-testid="input-reason"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="document">Document justificatif (optionnel)</Label>
                <Input
                  id="document"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  data-testid="input-document"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit" data-testid="button-submit-justification">
                  Envoyer
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Absences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-total-absences">
              {totalAbsences}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Ce trimestre
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Justifiées</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600" data-testid="stat-justified">
              {justified}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Validées
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Non justifiées</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive" data-testid="stat-unjustified">
              {unjustified}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              À justifier
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">En attente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-chart-4" data-testid="stat-pending">
              {pending}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              En validation
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="space-y-6">
        <TabsList>
          <TabsTrigger value="all">Toutes</TabsTrigger>
          <TabsTrigger value="unjustified">Non justifiées</TabsTrigger>
          <TabsTrigger value="pending">En attente</TabsTrigger>
          <TabsTrigger value="justified">Justifiées</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {absences.map((absence) => (
              <AbsenceCard key={absence.id} {...absence} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="unjustified" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {absences
              .filter((a) => a.status === "unjustified")
              .map((absence) => (
                <AbsenceCard key={absence.id} {...absence} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="pending" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {absences
              .filter((a) => a.status === "pending")
              .map((absence) => (
                <AbsenceCard key={absence.id} {...absence} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="justified" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {absences
              .filter((a) => a.status === "justified")
              .map((absence) => (
                <AbsenceCard key={absence.id} {...absence} />
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
