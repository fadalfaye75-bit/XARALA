import { ScheduleCard } from "@/components/ScheduleCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const schedule = {
  monday: [
    { subject: "Mathématiques", time: "08:00 - 09:30", room: "Salle A101", teacher: "M. Benali", type: "cours" as const },
    { subject: "Physique-Chimie", time: "10:00 - 11:30", room: "Lab 203", teacher: "Mme. Amrani", type: "tp" as const },
    { subject: "Français", time: "14:00 - 15:30", room: "Salle B205", teacher: "Mme. Fassi", type: "cours" as const },
    { subject: "Sport", time: "16:00 - 17:30", room: "Gymnase", teacher: "M. Tazi", type: "cours" as const },
  ],
  tuesday: [
    { subject: "Anglais", time: "08:00 - 09:30", room: "Salle C102", teacher: "Mme. Smith", type: "cours" as const },
    { subject: "SVT", time: "10:00 - 11:30", room: "Lab Bio", teacher: "M. Alaoui", type: "tp" as const },
    { subject: "Mathématiques", time: "14:00 - 15:30", room: "Salle A101", teacher: "M. Benali", type: "td" as const },
    { subject: "Histoire-Géo", time: "16:00 - 17:30", room: "Salle B203", teacher: "M. Cherkaoui", type: "cours" as const },
  ],
  wednesday: [
    { subject: "Physique-Chimie", time: "08:00 - 09:30", room: "Salle A203", teacher: "Mme. Amrani", type: "cours" as const },
    { subject: "Arabe", time: "10:00 - 11:30", room: "Salle D101", teacher: "M. Idrissi", type: "cours" as const },
    { subject: "Informatique", time: "14:00 - 16:00", room: "Salle Info 1", teacher: "M. Tazi", type: "tp" as const },
  ],
};

export default function SchedulePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Emploi du temps</h1>
        <p className="text-muted-foreground">
          Votre planning hebdomadaire de cours
        </p>
      </div>

      <Tabs defaultValue="monday" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5 lg:w-auto">
          <TabsTrigger value="monday">Lundi</TabsTrigger>
          <TabsTrigger value="tuesday">Mardi</TabsTrigger>
          <TabsTrigger value="wednesday">Mercredi</TabsTrigger>
          <TabsTrigger value="thursday">Jeudi</TabsTrigger>
          <TabsTrigger value="friday">Vendredi</TabsTrigger>
        </TabsList>

        <TabsContent value="monday">
          <Card>
            <CardHeader>
              <CardTitle>Lundi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {schedule.monday.map((item, index) => (
                <ScheduleCard key={index} {...item} />
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tuesday">
          <Card>
            <CardHeader>
              <CardTitle>Mardi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {schedule.tuesday.map((item, index) => (
                <ScheduleCard key={index} {...item} />
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="wednesday">
          <Card>
            <CardHeader>
              <CardTitle>Mercredi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {schedule.wednesday.map((item, index) => (
                <ScheduleCard key={index} {...item} />
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="thursday">
          <Card>
            <CardHeader>
              <CardTitle>Jeudi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground text-center py-8">
                Pas de cours le jeudi
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="friday">
          <Card>
            <CardHeader>
              <CardTitle>Vendredi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <ScheduleCard
                subject="Éducation Islamique"
                time="08:00 - 09:30"
                room="Salle D205"
                teacher="M. Bennani"
                type="cours"
              />
              <ScheduleCard
                subject="Français"
                time="10:00 - 11:30"
                room="Salle B205"
                teacher="Mme. Fassi"
                type="td"
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
