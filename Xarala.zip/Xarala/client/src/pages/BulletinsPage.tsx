import { BulletinCard } from "@/components/BulletinCard";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function BulletinsPage() {
  const bulletins = [
    {
      trimester: "Trimestre 2",
      year: "2024-2025",
      average: 15.8,
      rank: 3,
      totalStudents: 28,
      subjects: [
        { name: "Mathématiques", grade: 17.5, coefficient: 3 },
        { name: "Physique-Chimie", grade: 16, coefficient: 2 },
        { name: "SVT", grade: 15.5, coefficient: 2 },
        { name: "Français", grade: 14.5, coefficient: 2 },
        { name: "Anglais", grade: 16.5, coefficient: 2 },
        { name: "Arabe", grade: 15, coefficient: 1 },
        { name: "Histoire-Géo", grade: 15, coefficient: 1 },
      ],
    },
    {
      trimester: "Trimestre 1",
      year: "2024-2025",
      average: 14.2,
      rank: 5,
      totalStudents: 28,
      subjects: [
        { name: "Mathématiques", grade: 15, coefficient: 3 },
        { name: "Physique-Chimie", grade: 14.5, coefficient: 2 },
        { name: "SVT", grade: 13.5, coefficient: 2 },
        { name: "Français", grade: 13, coefficient: 2 },
        { name: "Anglais", grade: 15.5, coefficient: 2 },
        { name: "Arabe", grade: 14, coefficient: 1 },
        { name: "Histoire-Géo", grade: 14.5, coefficient: 1 },
      ],
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Bulletins Scolaires</h1>
          <p className="text-muted-foreground">
            Consultez et téléchargez vos bulletins
          </p>
        </div>
        <Select defaultValue="2024-2025">
          <SelectTrigger className="w-48" data-testid="select-year">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="2024-2025">2024-2025</SelectItem>
            <SelectItem value="2023-2024">2023-2024</SelectItem>
            <SelectItem value="2022-2023">2022-2023</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {bulletins.map((bulletin, index) => (
          <BulletinCard
            key={index}
            {...bulletin}
            onView={() => console.log(`View bulletin ${index}`)}
            onDownload={() => console.log(`Download bulletin ${index}`)}
          />
        ))}
      </div>
    </div>
  );
}
