import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Plus, MoreVertical, Edit, Trash2, Users, BookOpen } from "lucide-react";

interface Class {
  id: string;
  name: string;
  level: string;
  studentsCount: number;
  teacher: string;
  subjects: string[];
  schedule: string;
}

export default function ClassesPage() {
  const [openAddDialog, setOpenAddDialog] = useState(false);
  const [editingClass, setEditingClass] = useState<Class | null>(null);
  const [deleteClassId, setDeleteClassId] = useState<string | null>(null);

  const [classes] = useState<Class[]>([
    {
      id: "1",
      name: "3ème A",
      level: "3ème",
      studentsCount: 28,
      teacher: "M. Benali",
      subjects: ["Mathématiques", "Physique", "Français", "Arabe"],
      schedule: "Lun-Ven 08:00-16:00",
    },
    {
      id: "2",
      name: "3ème B",
      level: "3ème",
      studentsCount: 25,
      teacher: "Mme. Fassi",
      subjects: ["Mathématiques", "Physique", "Français", "Arabe"],
      schedule: "Lun-Ven 08:00-16:00",
    },
    {
      id: "3",
      name: "4ème A",
      level: "4ème",
      studentsCount: 30,
      teacher: "M. Tazi",
      subjects: ["Mathématiques", "Physique", "SVT", "Français"],
      schedule: "Lun-Ven 08:00-16:00",
    },
    {
      id: "4",
      name: "4ème B",
      level: "4ème",
      studentsCount: 27,
      teacher: "Mme. Amrani",
      subjects: ["Mathématiques", "Physique", "SVT", "Français"],
      schedule: "Lun-Ven 08:00-16:00",
    },
  ]);

  const [formData, setFormData] = useState({
    name: "",
    level: "",
    teacher: "",
    schedule: "",
  });

  const stats = [
    {
      label: "Total Classes",
      value: classes.length,
      color: "text-foreground",
    },
    {
      label: "Total Élèves",
      value: classes.reduce((sum, c) => sum + c.studentsCount, 0),
      color: "text-chart-1",
    },
    {
      label: "Niveau 3ème",
      value: classes.filter((c) => c.level === "3ème").length,
      color: "text-chart-2",
    },
    {
      label: "Niveau 4ème",
      value: classes.filter((c) => c.level === "4ème").length,
      color: "text-chart-3",
    },
  ];

  const handleOpenAddDialog = () => {
    setEditingClass(null);
    setFormData({
      name: "",
      level: "",
      teacher: "",
      schedule: "",
    });
    setOpenAddDialog(true);
  };

  const handleEditClass = (classItem: Class) => {
    setEditingClass(classItem);
    setFormData({
      name: classItem.name,
      level: classItem.level,
      teacher: classItem.teacher,
      schedule: classItem.schedule,
    });
    setOpenAddDialog(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log(editingClass ? "Updating class:" : "Creating class:", formData);
    setOpenAddDialog(false);
  };

  const handleDeleteClass = (classId: string) => {
    console.log("Deleting class:", classId);
    setDeleteClassId(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold">Gestion des Classes</h1>
          <p className="text-muted-foreground">
            Gérez les classes et leur organisation
          </p>
        </div>
        <Button onClick={handleOpenAddDialog} data-testid="button-add-class">
          <Plus className="h-4 w-4 mr-2" />
          Ajouter une classe
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${stat.color}`}>
                {stat.value}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {classes.map((classItem) => (
          <Card key={classItem.id} className="hover-elevate">
            <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-3">
              <div className="flex-1">
                <CardTitle className="text-xl" data-testid={`class-name-${classItem.id}`}>
                  {classItem.name}
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {classItem.teacher}
                </p>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    data-testid={`button-actions-${classItem.id}`}
                  >
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => handleEditClass(classItem)}
                    data-testid={`action-edit-${classItem.id}`}
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Modifier
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-destructive"
                    onClick={() => setDeleteClassId(classItem.id)}
                    data-testid={`action-delete-${classItem.id}`}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Supprimer
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="h-4 w-4" />
                  <span>{classItem.studentsCount} élèves</span>
                </div>
                <Badge variant="outline">{classItem.level}</Badge>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Matières:</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {classItem.subjects.slice(0, 3).map((subject, idx) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {subject}
                    </Badge>
                  ))}
                  {classItem.subjects.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{classItem.subjects.length - 3}
                    </Badge>
                  )}
                </div>
              </div>

              <div className="pt-2 border-t">
                <p className="text-xs text-muted-foreground">
                  Horaire: {classItem.schedule}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Add/Edit Class Dialog */}
      <Dialog open={openAddDialog} onOpenChange={setOpenAddDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingClass ? "Modifier la classe" : "Ajouter une classe"}
            </DialogTitle>
            <DialogDescription>
              {editingClass
                ? "Modifiez les informations de la classe"
                : "Remplissez les informations pour créer une nouvelle classe"}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nom de la classe</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Ex: 3ème A"
                required
                data-testid="input-class-name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="level">Niveau</Label>
              <Select
                value={formData.level}
                onValueChange={(value) => setFormData({ ...formData, level: value })}
              >
                <SelectTrigger id="level" data-testid="select-class-level">
                  <SelectValue placeholder="Sélectionner un niveau" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1ère">1ère année</SelectItem>
                  <SelectItem value="2ème">2ème année</SelectItem>
                  <SelectItem value="3ème">3ème année</SelectItem>
                  <SelectItem value="4ème">4ème année</SelectItem>
                  <SelectItem value="5ème">5ème année</SelectItem>
                  <SelectItem value="6ème">6ème année</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="teacher">Professeur principal</Label>
              <Input
                id="teacher"
                value={formData.teacher}
                onChange={(e) => setFormData({ ...formData, teacher: e.target.value })}
                placeholder="Ex: M. Benali"
                required
                data-testid="input-class-teacher"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="schedule">Horaire</Label>
              <Input
                id="schedule"
                value={formData.schedule}
                onChange={(e) => setFormData({ ...formData, schedule: e.target.value })}
                placeholder="Ex: Lun-Ven 08:00-16:00"
                required
                data-testid="input-class-schedule"
              />
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpenAddDialog(false)}
              >
                Annuler
              </Button>
              <Button type="submit" data-testid="button-submit-class">
                {editingClass ? "Mettre à jour" : "Créer"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteClassId} onOpenChange={() => setDeleteClassId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer cette classe ? Cette action est
              irréversible et affectera tous les élèves associés.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteClassId && handleDeleteClass(deleteClassId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
