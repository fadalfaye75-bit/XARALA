import { GradeInputTable } from "@/components/GradeInputTable";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function GradeInputPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold">Saisie des Notes</h1>
          <p className="text-muted-foreground">
            Entrez les notes de vos élèves
          </p>
        </div>
        <div className="flex gap-3">
          <Select defaultValue="3a">
            <SelectTrigger className="w-32" data-testid="select-class">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="3a">3ème A</SelectItem>
              <SelectItem value="3b">3ème B</SelectItem>
              <SelectItem value="4a">4ème A</SelectItem>
              <SelectItem value="4b">4ème B</SelectItem>
            </SelectContent>
          </Select>
          
          <Select defaultValue="math">
            <SelectTrigger className="w-40" data-testid="select-subject">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="math">Mathématiques</SelectItem>
              <SelectItem value="physics">Physique</SelectItem>
              <SelectItem value="french">Français</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <GradeInputTable
        onSave={(grades) => console.log("Grades saved:", grades)}
      />
    </div>
  );
}
