import { GradeCard } from "@/components/GradeCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function NotesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Mes Notes</h1>
          <p className="text-muted-foreground">
            Consultez toutes vos notes et évaluations
          </p>
        </div>
        <Select defaultValue="t2">
          <SelectTrigger className="w-48" data-testid="select-trimester">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="t1">Trimestre 1</SelectItem>
            <SelectItem value="t2">Trimestre 2</SelectItem>
            <SelectItem value="t3">Trimestre 3</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="all" className="space-y-6">
        <TabsList>
          <TabsTrigger value="all">Toutes les matières</TabsTrigger>
          <TabsTrigger value="scientific">Scientifiques</TabsTrigger>
          <TabsTrigger value="literary">Littéraires</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sciences</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <GradeCard
                  subject="Mathématiques"
                  grade={17.5}
                  maxGrade={20}
                  coefficient={3}
                  average={13.2}
                  date="15 Jan 2025"
                />
                <GradeCard
                  subject="Physique-Chimie"
                  grade={16}
                  maxGrade={20}
                  coefficient={2}
                  average={12.8}
                  date="12 Jan 2025"
                />
                <GradeCard
                  subject="SVT"
                  grade={15.5}
                  maxGrade={20}
                  coefficient={2}
                  average={13.5}
                  date="10 Jan 2025"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Langues et Littérature</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <GradeCard
                  subject="Français"
                  grade={14.5}
                  maxGrade={20}
                  coefficient={2}
                  average={12.3}
                  date="14 Jan 2025"
                />
                <GradeCard
                  subject="Anglais"
                  grade={16.5}
                  maxGrade={20}
                  coefficient={2}
                  average={13.8}
                  date="11 Jan 2025"
                />
                <GradeCard
                  subject="Arabe"
                  grade={15}
                  maxGrade={20}
                  coefficient={1}
                  average={14.2}
                  date="09 Jan 2025"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Sciences Humaines et Arts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <GradeCard
                  subject="Histoire-Géographie"
                  grade={15}
                  maxGrade={20}
                  coefficient={1}
                  average={13.1}
                  date="13 Jan 2025"
                />
                <GradeCard
                  subject="Éducation Islamique"
                  grade={17}
                  maxGrade={20}
                  coefficient={1}
                  average={15.2}
                  date="08 Jan 2025"
                />
                <GradeCard
                  subject="Sport"
                  grade={18}
                  maxGrade={20}
                  coefficient={1}
                  average={15.8}
                  date="16 Jan 2025"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scientific">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <GradeCard
              subject="Mathématiques"
              grade={17.5}
              maxGrade={20}
              coefficient={3}
              average={13.2}
              date="15 Jan 2025"
            />
            <GradeCard
              subject="Physique-Chimie"
              grade={16}
              maxGrade={20}
              coefficient={2}
              average={12.8}
              date="12 Jan 2025"
            />
            <GradeCard
              subject="SVT"
              grade={15.5}
              maxGrade={20}
              coefficient={2}
              average={13.5}
              date="10 Jan 2025"
            />
          </div>
        </TabsContent>

        <TabsContent value="literary">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <GradeCard
              subject="Français"
              grade={14.5}
              maxGrade={20}
              coefficient={2}
              average={12.3}
              date="14 Jan 2025"
            />
            <GradeCard
              subject="Anglais"
              grade={16.5}
              maxGrade={20}
              coefficient={2}
              average={13.8}
              date="11 Jan 2025"
            />
            <GradeCard
              subject="Arabe"
              grade={15}
              maxGrade={20}
              coefficient={1}
              average={14.2}
              date="09 Jan 2025"
            />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
