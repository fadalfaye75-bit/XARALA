import { useState } from "react";
import { ReclamationCard } from "@/components/ReclamationCard";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function ReclamationsPage() {
  const [open, setOpen] = useState(false);

  const reclamations = [
    {
      id: "1",
      title: "Contestation note de mathématiques",
      description: "Je souhaiterais discuter de ma note de l'examen du 15 janvier. Il me semble qu'il y a une erreur dans le calcul de la moyenne.",
      status: "pending" as const,
      date: "20 Jan 2025",
      category: "Notes",
    },
    {
      id: "2",
      title: "Demande de certificat de scolarité",
      description: "J'ai besoin d'un certificat de scolarité pour une démarche administrative urgente.",
      status: "resolved" as const,
      date: "18 Jan 2025",
      category: "Administratif",
    },
    {
      id: "3",
      title: "Problème d'emploi du temps",
      description: "Conflit d'horaires entre le cours de physique et les travaux pratiques de chimie.",
      status: "in-progress" as const,
      date: "19 Jan 2025",
      category: "Emploi du temps",
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Réclamation soumise");
    setOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Réclamations</h1>
          <p className="text-muted-foreground">
            Gérez vos demandes et réclamations
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-new-reclamation">
              <Plus className="h-4 w-4 mr-2" />
              Nouvelle Réclamation
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Nouvelle Réclamation</DialogTitle>
              <DialogDescription>
                Soumettez une nouvelle demande ou réclamation
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="category">Catégorie</Label>
                <Select>
                  <SelectTrigger id="category" data-testid="select-category">
                    <SelectValue placeholder="Sélectionnez une catégorie" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="notes">Notes</SelectItem>
                    <SelectItem value="admin">Administratif</SelectItem>
                    <SelectItem value="schedule">Emploi du temps</SelectItem>
                    <SelectItem value="other">Autre</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="title">Titre</Label>
                <Input
                  id="title"
                  placeholder="Résumé de votre réclamation"
                  data-testid="input-title"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Décrivez votre demande en détail..."
                  rows={4}
                  data-testid="input-description"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit" data-testid="button-submit">
                  Soumettre
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="all" className="space-y-6">
        <TabsList>
          <TabsTrigger value="all">Toutes</TabsTrigger>
          <TabsTrigger value="pending">En attente</TabsTrigger>
          <TabsTrigger value="in-progress">En cours</TabsTrigger>
          <TabsTrigger value="resolved">Résolues</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {reclamations.map((reclamation) => (
              <ReclamationCard
                key={reclamation.id}
                {...reclamation}
                onView={() => console.log(`View ${reclamation.id}`)}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="pending" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {reclamations
              .filter((r) => r.status === "pending")
              .map((reclamation) => (
                <ReclamationCard
                  key={reclamation.id}
                  {...reclamation}
                  onView={() => console.log(`View ${reclamation.id}`)}
                />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="in-progress" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {reclamations
              .filter((r) => r.status === "in-progress")
              .map((reclamation) => (
                <ReclamationCard
                  key={reclamation.id}
                  {...reclamation}
                  onView={() => console.log(`View ${reclamation.id}`)}
                />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="resolved" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {reclamations
              .filter((r) => r.status === "resolved")
              .map((reclamation) => (
                <ReclamationCard
                  key={reclamation.id}
                  {...reclamation}
                  onView={() => console.log(`View ${reclamation.id}`)}
                />
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
