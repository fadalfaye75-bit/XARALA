import { BookOpen, TrendingUp, Calendar, FileText, Users, MessageSquare } from "lucide-react";
import { StatCard } from "@/components/StatCard";
import { GradeCard } from "@/components/GradeCard";
import { ScheduleCard } from "@/components/ScheduleCard";
import { ReclamationCard } from "@/components/ReclamationCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

type UserRole = "student" | "teacher" | "parent" | "secretary";

interface DashboardProps {
  userRole?: UserRole;
}

export default function Dashboard({ userRole = "student" }: DashboardProps) {
  const renderStudentDashboard = () => (
    <>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Moyenne Générale"
          value="15.8/20"
          icon={BookOpen}
          description="Trimestre 2, 2024-2025"
          trend={{ value: 5, isPositive: true }}
        />
        <StatCard
          title="Classement"
          value="3/28"
          icon={TrendingUp}
          description="Dans la classe"
        />
        <StatCard
          title="Prochaine Évaluation"
          value="Lundi"
          icon={Calendar}
          description="Mathématiques"
        />
        <StatCard
          title="Réclamations"
          value="1"
          icon={MessageSquare}
          description="En attente"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
            <CardTitle>Dernières Notes</CardTitle>
            <Button variant="ghost" size="sm">
              Voir tout <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <GradeCard
              subject="Mathématiques"
              grade={17.5}
              maxGrade={20}
              coefficient={3}
              average={13.2}
              date="15 Jan 2025"
            />
            <GradeCard
              subject="Physique"
              grade={14}
              maxGrade={20}
              coefficient={2}
              average={12.8}
              date="12 Jan 2025"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
            <CardTitle>Emploi du temps - Aujourd'hui</CardTitle>
            <Button variant="ghost" size="sm">
              Semaine <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <ScheduleCard
              subject="Mathématiques"
              time="08:00 - 09:30"
              room="Salle A101"
              teacher="M. Benali"
              type="cours"
            />
            <ScheduleCard
              subject="Physique"
              time="10:00 - 11:30"
              room="Lab 203"
              teacher="Mme. Amrani"
              type="tp"
            />
          </CardContent>
        </Card>
      </div>
    </>
  );

  const renderTeacherDashboard = () => (
    <>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Mes Classes"
          value="4"
          icon={Users}
          description="Classes assignées"
        />
        <StatCard
          title="Élèves Total"
          value="112"
          icon={Users}
          description="Tous niveaux"
        />
        <StatCard
          title="Notes à Saisir"
          value="24"
          icon={BookOpen}
          description="Évaluations en attente"
        />
        <StatCard
          title="Réclamations"
          value="3"
          icon={MessageSquare}
          description="À traiter"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
            <CardTitle>Emploi du temps - Aujourd'hui</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <ScheduleCard
              subject="Mathématiques - 3A"
              time="08:00 - 09:30"
              room="Salle A101"
              type="cours"
            />
            <ScheduleCard
              subject="Mathématiques - 3B"
              time="10:00 - 11:30"
              room="Salle A102"
              type="cours"
            />
            <ScheduleCard
              subject="Mathématiques - 4A"
              time="14:00 - 15:30"
              room="Salle A101"
              type="td"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
            <CardTitle>Réclamations Récentes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <ReclamationCard
              id="1"
              title="Contestation note - Ahmed Ben Ali"
              description="Demande de révision de la note du DS du 15/01"
              status="pending"
              date="20 Jan 2025"
              category="Notes"
              onView={() => console.log("View")}
            />
          </CardContent>
        </Card>
      </div>
    </>
  );

  const renderParentDashboard = () => (
    <>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Moyenne - Salma"
          value="15.8/20"
          icon={BookOpen}
          description="Trimestre 2"
          trend={{ value: 5, isPositive: true }}
        />
        <StatCard
          title="Moyenne - Youssef"
          value="13.2/20"
          icon={BookOpen}
          description="Trimestre 2"
          trend={{ value: -2, isPositive: false }}
        />
        <StatCard
          title="Bulletins"
          value="2"
          icon={FileText}
          description="Disponibles"
        />
        <StatCard
          title="Réclamations"
          value="0"
          icon={MessageSquare}
          description="En cours"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Aperçu des Enfants</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold mb-3">Salma Ouardi - 3ème A</h3>
            <div className="grid gap-3 md:grid-cols-2">
              <GradeCard
                subject="Mathématiques"
                grade={17.5}
                maxGrade={20}
                coefficient={3}
                date="15 Jan 2025"
              />
              <GradeCard
                subject="Physique"
                grade={16}
                maxGrade={20}
                coefficient={2}
                date="12 Jan 2025"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );

  const renderSecretaryDashboard = () => (
    <>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Utilisateurs Total"
          value="458"
          icon={Users}
          description="Tous les rôles"
        />
        <StatCard
          title="Classes Actives"
          value="18"
          icon={BookOpen}
          description="Année en cours"
        />
        <StatCard
          title="Réclamations"
          value="12"
          icon={MessageSquare}
          description="À traiter"
        />
        <StatCard
          title="Bulletins Générés"
          value="432"
          icon={FileText}
          description="Ce trimestre"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Réclamations à Traiter</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <ReclamationCard
              id="1"
              title="Demande certificat de scolarité"
              description="Certificat nécessaire pour démarche administrative"
              status="pending"
              date="20 Jan 2025"
              category="Administratif"
              onView={() => console.log("View")}
            />
            <ReclamationCard
              id="2"
              title="Modification emploi du temps"
              description="Conflit d'horaires signalé"
              status="in-progress"
              date="19 Jan 2025"
              category="Emploi du temps"
              onView={() => console.log("View")}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Statistiques Rapides</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Élèves</span>
                <span className="font-semibold">312</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Professeurs</span>
                <span className="font-semibold">45</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Parents</span>
                <span className="font-semibold">98</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Personnel Admin</span>
                <span className="font-semibold">3</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );

  const renderDashboard = () => {
    switch (userRole) {
      case "teacher":
        return renderTeacherDashboard();
      case "parent":
        return renderParentDashboard();
      case "secretary":
        return renderSecretaryDashboard();
      default:
        return renderStudentDashboard();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Tableau de bord</h1>
        <p className="text-muted-foreground">
          Bienvenue sur votre espace SIR
        </p>
      </div>

      {renderDashboard()}
    </div>
  );
}
