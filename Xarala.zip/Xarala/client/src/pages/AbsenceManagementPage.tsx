import { AbsenceManagementTable } from "@/components/AbsenceManagementTable";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AbsenceManagementPage() {
  const stats = [
    { label: "Absences aujourd'hui", value: "12", color: "text-chart-4" },
    { label: "Absences ce mois", value: "145", color: "text-foreground" },
    { label: "En attente validation", value: "8", color: "text-chart-4" },
    { label: "Taux de présence", value: "94%", color: "text-green-600" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold">Gestion des Absences</h1>
          <p className="text-muted-foreground">
            Marquez les présences et gérez les absences
          </p>
        </div>
        <div className="flex gap-3">
          <Select defaultValue="3a">
            <SelectTrigger className="w-32" data-testid="select-class">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="3a">3ème A</SelectItem>
              <SelectItem value="3b">3ème B</SelectItem>
              <SelectItem value="4a">4ème A</SelectItem>
              <SelectItem value="4b">4ème B</SelectItem>
            </SelectContent>
          </Select>
          
          <Select defaultValue="math">
            <SelectTrigger className="w-40" data-testid="select-subject">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="math">Mathématiques</SelectItem>
              <SelectItem value="physics">Physique</SelectItem>
              <SelectItem value="french">Français</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${stat.color}`}>
                {stat.value}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <AbsenceManagementTable
        onSave={(absences) => console.log("Absences saved:", absences)}
      />
    </div>
  );
}
