import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface GradeCardProps {
  subject: string;
  grade: number;
  maxGrade: number;
  coefficient?: number;
  average?: number;
  date?: string;
}

export function GradeCard({ 
  subject, 
  grade, 
  maxGrade, 
  coefficient = 1, 
  average,
  date 
}: GradeCardProps) {
  const percentage = (grade / maxGrade) * 100;
  const gradeColor = 
    percentage >= 80 ? "text-green-600" :
    percentage >= 60 ? "text-chart-3" :
    percentage >= 40 ? "text-chart-4" :
    "text-destructive";

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-3">
        <CardTitle className="text-base font-semibold">{subject}</CardTitle>
        {coefficient > 1 && (
          <Badge variant="secondary" className="text-xs">
            Coeff. {coefficient}
          </Badge>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-baseline justify-between">
          <div>
            <span className={`text-3xl font-bold ${gradeColor}`} data-testid={`grade-${subject.toLowerCase().replace(/\s+/g, "-")}`}>
              {grade.toFixed(1)}
            </span>
            <span className="text-muted-foreground">/{maxGrade}</span>
          </div>
          {average && (
            <div className="text-right">
              <div className="text-xs text-muted-foreground">Moyenne classe</div>
              <div className="text-sm font-medium">{average.toFixed(1)}/{maxGrade}</div>
            </div>
          )}
        </div>
        
        <Progress value={percentage} className="h-2" />
        
        {date && (
          <p className="text-xs text-muted-foreground">
            Évaluation du {date}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
