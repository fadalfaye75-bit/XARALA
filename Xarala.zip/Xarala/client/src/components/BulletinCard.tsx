import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Eye } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface Subject {
  name: string;
  grade: number;
  coefficient: number;
}

interface BulletinCardProps {
  trimester: string;
  year: string;
  average: number;
  rank?: number;
  totalStudents?: number;
  subjects: Subject[];
  onView?: () => void;
  onDownload?: () => void;
}

export function BulletinCard({
  trimester,
  year,
  average,
  rank,
  totalStudents,
  subjects,
  onView,
  onDownload,
}: BulletinCardProps) {
  const percentage = (average / 20) * 100;
  const gradeColor = 
    average >= 16 ? "text-green-600" :
    average >= 12 ? "text-chart-3" :
    average >= 10 ? "text-chart-4" :
    "text-destructive";

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-4">
        <div>
          <CardTitle className="text-lg font-bold" data-testid={`bulletin-${trimester.toLowerCase()}-${year}`}>
            {trimester} {year}
          </CardTitle>
          {rank && totalStudents && (
            <p className="text-sm text-muted-foreground mt-1">
              Classement: {rank}/{totalStudents}
            </p>
          )}
        </div>
        <div className="flex gap-2">
          {onView && (
            <Button variant="outline" size="sm" onClick={onView} data-testid="button-view-bulletin">
              <Eye className="h-4 w-4" />
            </Button>
          )}
          {onDownload && (
            <Button variant="outline" size="sm" onClick={onDownload} data-testid="button-download-bulletin">
              <Download className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex items-baseline justify-between mb-2">
            <span className="text-sm text-muted-foreground">Moyenne générale</span>
            <span className={`text-2xl font-bold ${gradeColor}`}>
              {average.toFixed(2)}/20
            </span>
          </div>
          <Progress value={percentage} className="h-2" />
        </div>

        <div className="space-y-2">
          <p className="text-sm font-medium">Détail par matière:</p>
          <div className="space-y-1">
            {subjects.slice(0, 3).map((subject, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{subject.name}</span>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    Coeff. {subject.coefficient}
                  </Badge>
                  <span className="font-medium w-12 text-right">
                    {subject.grade.toFixed(1)}/20
                  </span>
                </div>
              </div>
            ))}
            {subjects.length > 3 && (
              <p className="text-xs text-muted-foreground italic">
                +{subjects.length - 3} autres matières...
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
