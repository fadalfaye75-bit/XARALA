import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Save } from "lucide-react";

interface Student {
  id: string;
  name: string;
  number: string;
}

interface GradeInputTableProps {
  className?: string;
  subject?: string;
  evaluationType?: string;
  maxGrade?: number;
  students?: Student[];
  onSave?: (grades: Record<string, number>) => void;
}

export function GradeInputTable({
  className = "3A",
  subject = "Mathématiques",
  evaluationType = "Devoir surveillé",
  maxGrade = 20,
  students = [
    { id: "1", name: "Ahmed Ben Ali", number: "001" },
    { id: "2", name: "Fatima Zohra", number: "002" },
    { id: "3", name: "Karim Mansour", number: "003" },
    { id: "4", name: "Salma Ouardi", number: "004" },
    { id: "5", name: "Youssef Idrissi", number: "005" },
  ],
  onSave,
}: GradeInputTableProps) {
  const [grades, setGrades] = useState<Record<string, string>>({});

  const handleGradeChange = (studentId: string, value: string) => {
    setGrades({ ...grades, [studentId]: value });
  };

  const handleSave = () => {
    const numericGrades: Record<string, number> = {};
    Object.entries(grades).forEach(([id, value]) => {
      const num = parseFloat(value);
      if (!isNaN(num)) {
        numericGrades[id] = num;
      }
    });
    console.log("Saving grades:", numericGrades);
    onSave?.(numericGrades);
  };

  const calculateAverage = () => {
    const validGrades = Object.values(grades)
      .map(g => parseFloat(g))
      .filter(g => !isNaN(g));
    if (validGrades.length === 0) return 0;
    return validGrades.reduce((a, b) => a + b, 0) / validGrades.length;
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
        <div>
          <CardTitle>Saisie des notes - {subject}</CardTitle>
          <div className="flex gap-2 mt-2">
            <Badge variant="outline">{className}</Badge>
            <Badge variant="secondary">{evaluationType}</Badge>
          </div>
        </div>
        <Button onClick={handleSave} data-testid="button-save-grades">
          <Save className="h-4 w-4 mr-2" />
          Enregistrer
        </Button>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-24">N°</TableHead>
                <TableHead>Nom de l'élève</TableHead>
                <TableHead className="w-32">Note /{maxGrade}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students.map((student) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">{student.number}</TableCell>
                  <TableCell>{student.name}</TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      min="0"
                      max={maxGrade}
                      step="0.5"
                      value={grades[student.id] || ""}
                      onChange={(e) => handleGradeChange(student.id, e.target.value)}
                      placeholder="--"
                      className="w-24"
                      data-testid={`input-grade-${student.id}`}
                    />
                  </TableCell>
                </TableRow>
              ))}
              <TableRow className="bg-muted/50">
                <TableCell colSpan={2} className="font-semibold">
                  Moyenne de la classe
                </TableCell>
                <TableCell className="font-bold" data-testid="text-class-average">
                  {calculateAverage().toFixed(2)}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
