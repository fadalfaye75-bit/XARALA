import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock } from "lucide-react";

interface AbsenceCardProps {
  id: string;
  date: string;
  subject: string;
  period: string;
  status: "justified" | "unjustified" | "pending";
  reason?: string;
  teacher?: string;
}

const statusConfig = {
  justified: { label: "Justifiée", variant: "default" as const },
  unjustified: { label: "Non justifiée", variant: "destructive" as const },
  pending: { label: "En attente", variant: "secondary" as const },
};

export function AbsenceCard({
  id,
  date,
  subject,
  period,
  status,
  reason,
  teacher,
}: AbsenceCardProps) {
  const statusInfo = statusConfig[status];

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-3">
        <div className="flex-1">
          <CardTitle className="text-base font-semibold" data-testid={`absence-subject-${id}`}>
            {subject}
          </CardTitle>
          <div className="flex items-center gap-2 mt-2">
            <Badge variant={statusInfo.variant} className="text-xs">
              {statusInfo.label}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-1 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-3 w-3" />
            <span>{date}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>{period}</span>
          </div>
          {teacher && (
            <p className="text-xs text-muted-foreground">Prof. {teacher}</p>
          )}
        </div>
        
        {reason && (
          <div className="pt-2 border-t">
            <p className="text-xs text-muted-foreground">Motif:</p>
            <p className="text-sm mt-1">{reason}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
