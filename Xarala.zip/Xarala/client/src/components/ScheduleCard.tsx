import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin } from "lucide-react";

interface ScheduleCardProps {
  subject: string;
  time: string;
  room: string;
  teacher?: string;
  type?: "cours" | "td" | "tp" | "exam";
}

const typeColors = {
  cours: "default" as const,
  td: "secondary" as const,
  tp: "secondary" as const,
  exam: "destructive" as const,
};

const typeLabels = {
  cours: "Cours",
  td: "TD",
  tp: "TP",
  exam: "Examen",
};

export function ScheduleCard({ subject, time, room, teacher, type = "cours" }: ScheduleCardProps) {
  return (
    <Card className="hover-elevate">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h4 className="font-semibold" data-testid={`schedule-subject-${subject.toLowerCase().replace(/\s+/g, "-")}`}>
            {subject}
          </h4>
          <Badge variant={typeColors[type]} className="text-xs">
            {typeLabels[type]}
          </Badge>
        </div>
        
        <div className="space-y-1 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Clock className="h-3 w-3" />
            <span>{time}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-3 w-3" />
            <span>{room}</span>
          </div>
          {teacher && (
            <p className="text-xs mt-2">Prof. {teacher}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
