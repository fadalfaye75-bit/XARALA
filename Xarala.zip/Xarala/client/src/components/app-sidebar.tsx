import { 
  GraduationCap, 
  LayoutDashboard, 
  BookOpen, 
  Calendar, 
  FileText,
  MessageSquare,
  Users,
  Settings,
  ClipboardList
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Link, useLocation } from "wouter";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

const studentMenu = [
  { title: "Tableau de bord", url: "/", icon: LayoutDashboard },
  { title: "Mes Notes", url: "/notes", icon: BookOpen },
  { title: "Bulletins", url: "/bulletins", icon: FileText },
  { title: "Emploi du temps", url: "/emploi-du-temps", icon: Calendar },
  { title: "Mes Absences", url: "/absences", icon: ClipboardList },
  { title: "Réclamations", url: "/reclamations", icon: MessageSquare },
];

const teacherMenu = [
  { title: "Tableau de bord", url: "/", icon: LayoutDashboard },
  { title: "Saisie des notes", url: "/saisie-notes", icon: BookOpen },
  { title: "Gestion Absences", url: "/gestion-absences", icon: ClipboardList },
  { title: "Mes Classes", url: "/classes", icon: Users },
  { title: "Emploi du temps", url: "/emploi-du-temps", icon: Calendar },
  { title: "Réclamations", url: "/reclamations", icon: MessageSquare },
];

const parentMenu = [
  { title: "Tableau de bord", url: "/", icon: LayoutDashboard },
  { title: "Notes des enfants", url: "/notes", icon: BookOpen },
  { title: "Bulletins", url: "/bulletins", icon: FileText },
  { title: "Emploi du temps", url: "/emploi-du-temps", icon: Calendar },
  { title: "Absences", url: "/absences", icon: ClipboardList },
  { title: "Réclamations", url: "/reclamations", icon: MessageSquare },
];

const secretaryMenu = [
  { title: "Tableau de bord", url: "/", icon: LayoutDashboard },
  { title: "Gestion Utilisateurs", url: "/utilisateurs", icon: Users },
  { title: "Classes", url: "/classes", icon: GraduationCap },
  { title: "Gestion Absences", url: "/gestion-absences", icon: ClipboardList },
  { title: "Réclamations", url: "/reclamations", icon: MessageSquare },
  { title: "Paramètres", url: "/parametres", icon: Settings },
];

type UserRole = "student" | "teacher" | "parent" | "secretary";

interface AppSidebarProps {
  userRole?: UserRole;
  userName?: string;
}

const roleLabels: Record<UserRole, string> = {
  student: "Élève",
  teacher: "Professeur",
  parent: "Parent",
  secretary: "Secrétariat",
};

const roleColors: Record<UserRole, "default" | "secondary"> = {
  student: "default",
  teacher: "default",
  parent: "default",
  secretary: "secondary",
};

export function AppSidebar({ 
  userRole = "student",
  userName = "Jean Dupont"
}: AppSidebarProps) {
  const [location] = useLocation();

  const menuItems = {
    student: studentMenu,
    teacher: teacherMenu,
    parent: parentMenu,
    secretary: secretaryMenu,
  }[userRole];

  const initials = userName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <GraduationCap className="h-8 w-8 text-primary" />
          <div>
            <h2 className="text-lg font-semibold">SIR</h2>
            <p className="text-xs text-muted-foreground">Gestion Scolaire</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                    data-testid={`link-${item.title.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <Link href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9">
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{userName}</p>
            <Badge variant={roleColors[userRole]} className="mt-1 text-xs">
              {roleLabels[userRole]}
            </Badge>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
