import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Save } from "lucide-react";

interface Student {
  id: string;
  name: string;
  number: string;
}

interface AbsenceManagementTableProps {
  className?: string;
  subject?: string;
  date?: string;
  period?: string;
  students?: Student[];
  onSave?: (absences: string[]) => void;
}

export function AbsenceManagementTable({
  className = "3A",
  subject = "Mathématiques",
  date = "20 Jan 2025",
  period = "08:00 - 09:30",
  students = [
    { id: "1", name: "Ahmed Ben Ali", number: "001" },
    { id: "2", name: "Fatima Zohra", number: "002" },
    { id: "3", name: "Karim Mansour", number: "003" },
    { id: "4", name: "Salma Ouardi", number: "004" },
    { id: "5", name: "Youssef Idrissi", number: "005" },
  ],
  onSave,
}: AbsenceManagementTableProps) {
  const [absences, setAbsences] = useState<Set<string>>(new Set());

  const handleToggle = (studentId: string) => {
    const newAbsences = new Set(absences);
    if (newAbsences.has(studentId)) {
      newAbsences.delete(studentId);
    } else {
      newAbsences.add(studentId);
    }
    setAbsences(newAbsences);
  };

  const handleSave = () => {
    console.log("Saving absences:", Array.from(absences));
    onSave?.(Array.from(absences));
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
        <div>
          <CardTitle>Feuille d'appel - {subject}</CardTitle>
          <div className="flex gap-2 mt-2">
            <Badge variant="outline">{className}</Badge>
            <Badge variant="secondary">{date}</Badge>
            <Badge variant="secondary">{period}</Badge>
          </div>
        </div>
        <Button onClick={handleSave} data-testid="button-save-absences">
          <Save className="h-4 w-4 mr-2" />
          Enregistrer
        </Button>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-24">N°</TableHead>
                <TableHead>Nom de l'élève</TableHead>
                <TableHead className="w-32 text-center">Absent</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students.map((student) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">{student.number}</TableCell>
                  <TableCell>{student.name}</TableCell>
                  <TableCell className="text-center">
                    <Checkbox
                      checked={absences.has(student.id)}
                      onCheckedChange={() => handleToggle(student.id)}
                      data-testid={`checkbox-absence-${student.id}`}
                    />
                  </TableCell>
                </TableRow>
              ))}
              <TableRow className="bg-muted/50">
                <TableCell colSpan={2} className="font-semibold">
                  Total absents
                </TableCell>
                <TableCell className="font-bold text-center" data-testid="text-total-absences">
                  {absences.size}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
