import { BookOpen, TrendingUp } from "lucide-react";
import { StatCard } from "../StatCard";

export default function StatCardExample() {
  return (
    <div className="p-8 space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <StatCard
          title="Moyenne Générale"
          value="15.8/20"
          icon={BookOpen}
          description="Trimestre 2, 2024-2025"
          trend={{ value: 5, isPositive: true }}
        />
        <StatCard
          title="Progression"
          value="+12%"
          icon={TrendingUp}
          description="Amélioration continue"
        />
      </div>
    </div>
  );
}
