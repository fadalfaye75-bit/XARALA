import { GradeInputTable } from "../GradeInputTable";

export default function GradeInputTableExample() {
  return (
    <div className="p-8">
      <GradeInputTable
        onSave={(grades) => console.log("Grades saved:", grades)}
      />
    </div>
  );
}
