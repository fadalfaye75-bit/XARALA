import { BulletinCard } from "../BulletinCard";

export default function BulletinCardExample() {
  return (
    <div className="p-8">
      <div className="max-w-md">
        <BulletinCard
          trimester="Trimestre 2"
          year="2024-2025"
          average={15.8}
          rank={3}
          totalStudents={28}
          subjects={[
            { name: "Mathématiques", grade: 17.5, coefficient: 3 },
            { name: "Physique", grade: 16, coefficient: 2 },
            { name: "Français", grade: 14.5, coefficient: 2 },
            { name: "Histoire", grade: 15, coefficient: 1 },
            { name: "Anglais", grade: 16.5, coefficient: 2 },
          ]}
          onView={() => console.log("View bulletin")}
          onDownload={() => console.log("Download bulletin")}
        />
      </div>
    </div>
  );
}
