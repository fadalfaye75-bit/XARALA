import { AbsenceCard } from "../AbsenceCard";

export default function AbsenceCardExample() {
  return (
    <div className="p-8 space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <AbsenceCard
          id="1"
          date="20 Jan 2025"
          subject="Mathématiques"
          period="08:00 - 09:30"
          status="justified"
          reason="Rendez-vous médical"
          teacher="M. Benali"
        />
        <AbsenceCard
          id="2"
          date="18 Jan 2025"
          subject="Physique"
          period="10:00 - 11:30"
          status="unjustified"
          teacher="Mme. Amrani"
        />
        <AbsenceCard
          id="3"
          date="19 Jan 2025"
          subject="Français"
          period="14:00 - 15:30"
          status="pending"
          reason="Certificat médical en cours de validation"
          teacher="Mme. Fassi"
        />
      </div>
    </div>
  );
}
