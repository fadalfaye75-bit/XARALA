import { ReclamationCard } from "../ReclamationCard";

export default function ReclamationCardExample() {
  return (
    <div className="p-8 space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <ReclamationCard
          id="1"
          title="Contestation note de mathématiques"
          description="Je souhaiterais discuter de ma note de l'examen du 15 janvier. Il me semble qu'il y a une erreur dans le calcul."
          status="pending"
          date="20 Jan 2025"
          category="Notes"
          onView={() => console.log("View reclamation 1")}
        />
        <ReclamationCard
          id="2"
          title="Demande de certificat de scolarité"
          description="J'ai besoin d'un certificat de scolarité pour une démarche administrative."
          status="resolved"
          date="18 Jan 2025"
          category="Administratif"
          onView={() => console.log("View reclamation 2")}
        />
      </div>
    </div>
  );
}
