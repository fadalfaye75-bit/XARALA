import { GradeCard } from "../GradeCard";

export default function GradeCardExample() {
  return (
    <div className="p-8 space-y-4">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <GradeCard
          subject="Mathématiques"
          grade={17.5}
          maxGrade={20}
          coefficient={3}
          average={13.2}
          date="15 Jan 2025"
        />
        <GradeCard
          subject="Physique"
          grade={14}
          maxGrade={20}
          coefficient={2}
          average={12.8}
          date="12 Jan 2025"
        />
        <GradeCard
          subject="Français"
          grade={16}
          maxGrade={20}
          coefficient={2}
          average={14.5}
          date="10 Jan 2025"
        />
      </div>
    </div>
  );
}
