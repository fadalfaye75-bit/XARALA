import { ScheduleCard } from "../ScheduleCard";

export default function ScheduleCardExample() {
  return (
    <div className="p-8 space-y-4">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <ScheduleCard
          subject="Mathématiques"
          time="08:00 - 09:30"
          room="Salle A101"
          teacher="M. Benali"
          type="cours"
        />
        <ScheduleCard
          subject="Physique - Chimie"
          time="10:00 - 11:30"
          room="Lab 203"
          teacher="Mme. Amrani"
          type="tp"
        />
        <ScheduleCard
          subject="Informatique"
          time="14:00 - 16:00"
          room="Salle Info 1"
          teacher="M. Tazi"
          type="exam"
        />
      </div>
    </div>
  );
}
