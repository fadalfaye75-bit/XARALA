import { LoginPage } from "../LoginPage";
import { ThemeProvider } from "../ThemeProvider";

export default function LoginPageExample() {
  return (
    <ThemeProvider>
      <LoginPage onLogin={(role, username) => console.log("Login:", role, username)} />
    </ThemeProvider>
  );
}
