import { AbsenceManagementTable } from "../AbsenceManagementTable";

export default function AbsenceManagementTableExample() {
  return (
    <div className="p-8">
      <AbsenceManagementTable
        onSave={(absences) => console.log("Absences saved:", absences)}
      />
    </div>
  );
}
