import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MessageSquare } from "lucide-react";

interface ReclamationCardProps {
  id: string;
  title: string;
  description: string;
  status: "pending" | "in-progress" | "resolved" | "rejected";
  date: string;
  category: string;
  onView?: () => void;
}

const statusConfig = {
  pending: { label: "En attente", variant: "secondary" as const },
  "in-progress": { label: "En cours", variant: "default" as const },
  resolved: { label: "Résolu", variant: "default" as const },
  rejected: { label: "Rejeté", variant: "destructive" as const },
};

export function ReclamationCard({
  id,
  title,
  description,
  status,
  date,
  category,
  onView,
}: ReclamationCardProps) {
  const statusInfo = statusConfig[status];

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-3">
        <div className="flex-1">
          <CardTitle className="text-base font-semibold" data-testid={`reclamation-title-${id}`}>
            {title}
          </CardTitle>
          <div className="flex items-center gap-2 mt-2">
            <Badge variant="outline" className="text-xs">
              {category}
            </Badge>
            <Badge variant={statusInfo.variant} className="text-xs">
              {statusInfo.label}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground line-clamp-2">{description}</p>
        
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3" />
            <span>{date}</span>
          </div>
          {onView && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onView}
              data-testid={`button-view-reclamation-${id}`}
            >
              <MessageSquare className="h-4 w-4 mr-1" />
              Voir détails
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
