import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { ThemeProvider } from "./components/ThemeProvider";
import { ThemeToggle } from "./components/ThemeToggle";
import { AppSidebar } from "./components/app-sidebar";
import { LoginPage } from "./components/LoginPage";
import Dashboard from "./pages/Dashboard";
import NotesPage from "./pages/NotesPage";
import BulletinsPage from "./pages/BulletinsPage";
import SchedulePage from "./pages/SchedulePage";
import ReclamationsPage from "./pages/ReclamationsPage";
import GradeInputPage from "./pages/GradeInputPage";
import AbsencesPage from "./pages/AbsencesPage";
import AbsenceManagementPage from "./pages/AbsenceManagementPage";
import UsersManagementPage from "./pages/UsersManagementPage";
import ClassesPage from "./pages/ClassesPage";
import NotFound from "@/pages/not-found";

type UserRole = "student" | "teacher" | "parent" | "secretary";

function Router({ userRole }: { userRole: UserRole }) {
  return (
    <Switch>
      <Route path="/" component={() => <Dashboard userRole={userRole} />} />
      <Route path="/notes" component={NotesPage} />
      <Route path="/bulletins" component={BulletinsPage} />
      <Route path="/emploi-du-temps" component={SchedulePage} />
      <Route path="/absences" component={AbsencesPage} />
      <Route path="/reclamations" component={ReclamationsPage} />
      <Route path="/saisie-notes" component={GradeInputPage} />
      <Route path="/gestion-absences" component={AbsenceManagementPage} />
      <Route path="/utilisateurs" component={UsersManagementPage} />
      <Route path="/classes" component={ClassesPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<UserRole>("student");
  const [userName, setUserName] = useState("Jean Dupont");

  const handleLogin = (role: string, username: string) => {
    setUserRole(role as UserRole);
    setUserName(username);
    setIsLoggedIn(true);
  };

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  if (!isLoggedIn) {
    return (
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <TooltipProvider>
            <LoginPage onLogin={handleLogin} />
            <Toaster />
          </TooltipProvider>
        </ThemeProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <SidebarProvider style={style as React.CSSProperties}>
            <div className="flex h-screen w-full">
              <AppSidebar userRole={userRole} userName={userName} />
              <div className="flex flex-col flex-1">
                <header className="flex items-center justify-between gap-2 p-4 border-b">
                  <SidebarTrigger data-testid="button-sidebar-toggle" />
                  <ThemeToggle />
                </header>
                <main className="flex-1 overflow-auto p-6">
                  <Router userRole={userRole} />
                </main>
              </div>
            </div>
          </SidebarProvider>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
